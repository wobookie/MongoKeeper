// Get references to page elements
const statusMessage = document.getElementById("statusMessageId");

// Setup MongoDB Stitch
const APP_ID = "archive-jeqag";

const stitchClient = stitch.Stitch.initializeDefaultAppClient(APP_ID);
		

if (stitch.Stitch.hasAppClient(APP_ID)) {
	revealStatusContainer();
	statusMessage.innerText = "Client for ID " + APP_ID + " initialised."
} else {
	statusMessage.innerText = "Client for ID " + APP_ID + " not initialised!"
}

function initialiseStitchAppClient() {
	
}

function revealStatusContainer() {
	const container = document.getElementById("appstatus-container");
	container.classList.remove("hidden");
}